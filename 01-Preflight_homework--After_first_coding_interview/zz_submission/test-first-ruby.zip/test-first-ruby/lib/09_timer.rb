# # Topics
#
# * classes
# * instance variables
#   * attribute - an instance variable with accessor methods
#   * attr_reader, attr_writer, attr_accessor are shortcuts for vanilla getter/setter methods
# * def initialize to initialize an instance variable
# * string formatting
#   * Favor the use of sprintf and its alias format over the fairly cryptic String#% method.

class Timer
  
  attr_accessor :seconds
  
  def initialize
    @seconds= 0
  end
  
  def time_string
    total_seconds=      @seconds
    total_minutes=      total_seconds / 60
    
    seconds_to_display= total_seconds % 60 #  @seconds % 60
    minutes_to_display= total_minutes % 60 # (@seconds / 60) % 60
      hours_to_display= total_minutes / 60 # (@seconds / 60) / 60
    
    sprintf("%02d:%02d:%02d",
             hours_to_display,
             minutes_to_display,
             seconds_to_display)
  end
  
end