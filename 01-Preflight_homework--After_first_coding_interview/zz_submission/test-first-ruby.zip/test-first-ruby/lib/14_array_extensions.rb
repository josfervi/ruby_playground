class Array
  def sum
    
    unless self.all? {|x| x.is_a? Numeric}
      raise TypeError, "array contains non-numeric elements; array must not contain non-numeric elements"
    end
    
    sum= 0
    
    for x in self
      sum+= x
    end
    
    sum
  end
  
  def square
    
    unless self.all? {|x| x.is_a? Numeric}
      raise TypeError, "array contains non-numeric elements; array must not contain non-numeric elements"
    end
    
    self.map {|x| x**2}
  end
  
  def square!
    
    unless self.all? {|x| x.is_a? Numeric}
      raise TypeError, "array contains non-numeric elements; array must not contain non-numeric elements"
    end
    
    self.map! {|x| x**2}
  end
end

# Questions
# Q1: ln 52's x.is_not_a? Numeric
#     triggers an error
#     NoMethodError: undefined method `is_not_a?' for 1:Fixnum
#     
#     but Fixnum is an Object and
#     I implemented the is_not_a? method in the Oject class (lns 56-64)
#     so Fixnum should have an is_not_a? method
#
#     not sure how to fix this...
#
# Q2: I know I can use a function,
#     but can I use decorators to do the error handling
#     and not have to repeat myself?


# if self.any? {|x| x.is_not_a? Numeric}
#   raise TypeError, "array contains non-numeric elements; array must not contain non-numeric elements"
# end

# def Object
#   def is_not_a? cls
#     ! self.is_a? cls
#   end
  
#   def not_kind_of? cls
#     ! self.kind_of? cls
#   end
# end