FREEZING_POINT_IN_C=  0.0
FREEZING_POINT_IN_F= 32.0

# BOILING_POINT_IN_C= 100.0
# BOILING_POINT_IN_F= 212.0

C_OVER_F= 5.0/9.0 #   (BOILING_POINT_IN_C- FREEZING_POINT_IN_C) \
                  # / (BOILING_POINT_IN_F- FREEZING_POINT_IN_F)

F_OVER_C= 9.0/5.0

def ftoc( temperatureInF )
  C_OVER_F * (temperatureInF - FREEZING_POINT_IN_F)
end

def ctof( temperatureInC )
  (F_OVER_C * temperatureInC) + FREEZING_POINT_IN_F
end