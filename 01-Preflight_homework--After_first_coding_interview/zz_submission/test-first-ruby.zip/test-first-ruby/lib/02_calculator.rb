# Takes two numbers and adds them
# +a+:: +number+ first number
# +b+:: +number+ second number
def add(a, b)
  a + b
end

# Takes two numbers and subtracts the second from the first
# +a+:: +number+ first number
# +b+:: +number+ second number
def subtract(a,b)
  a-b
end

# Takes an array of numbers and adds them all together
# +numbers+:: the array of numbers
def sum(numbers)
  sum= 0
  
  for number in numbers
    sum+=  number
  end
  
  sum
end

# Multiplies two numbers together
# +a+:: first number
# +b+:: second number
def multiply(a, b)
  a * b
end

# Raises one number to the power of another number
# +x+:: +integer+ the base
# +n+:: +integer+ the exponent
def power(x, n)
  x ** n
end

# Computes the factorial of a number
# +n+:: +integer+ the number
def factorial(n)
  res= 1
  
  while n > 0
    res*= n
    n-= 1
  end
  
  res
end