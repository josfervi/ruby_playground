# h= Hash.new
#
# many problems can be solved by iterating through the hash
# h.each do |key, value|
#   ...
# end
#
# use is_a? to verify object type
# entry.is_a? Hash
#
# raise exceptions using raise
# raise TypeError, "error message here"
#
# to turn string prefix into a regexp
# /#{prefix}/
# then to find the index where a word matches that regexp
# regexp.match word
# or
# regexp =~ word
# e.g.
# /#{"fi"}/.match "find" #=> 0
#
# review the following good methods
#
#   def find prefix
#    
#     matches= Hash.new
#    
#     @entries.each do |key, value|
#       matches[key]= value if /#{prefix}/.match key
#     end
#    
#     matches
#   end
#  
#   def printable
#     str_entries= []
#    
#     @entries.each do |key, value|
#       str_entries.push %Q{[#{key}] "#{value}"}
#     end
#    
#     str_entries.sort.join("\n")
#   end

class Dictionary
  
  attr_reader :entries
  
  def initialize
    @entries= Hash.new
  end
  
  def add entry
    if entry.is_a? Hash
      entry.each do |key, value|
        @entries[key]= value
      end
    elsif entry.is_a? String
      key= entry
      @entries[key]= nil
    else
      raise TypeError, "entries must be a Hash or a String"
    end
  end
  
  def keywords
    @entries.keys.sort
  end
  
  def include? key
    @entries.keys.include? key
  end
  
  def find prefix
    
    matches= Hash.new
    
    @entries.each do |key, value|
      matches[key]= value if /#{prefix}/.match key
    end
    
    matches
  end
  
  def printable
    str_entries= []
    
    @entries.each do |key, value|
      str_entries.push %Q{[#{key}] "#{value}"}
    end
    
    str_entries.sort.join("\n")
  end
end