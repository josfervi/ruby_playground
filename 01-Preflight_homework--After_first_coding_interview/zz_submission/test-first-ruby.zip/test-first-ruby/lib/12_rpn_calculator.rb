# sometimes self, @, RPNCalculator are optional
# not sure exactly when though

# @value # maintains the value of last performed operation

# isolated error/exception handling to most pertinent method pop

# used :fdiv instead of :/ to bypass to_f conversions

class RPNCalculator
  
  attr_reader :value
  
  def initialize
    @values= []
    @value= nil # maintains the value of last performed operation
  end
  
  def push value
    @values.push value
  end
  
  def plus
    performOperation :+
  end
  
  def minus
    performOperation :-
  end
  
  def times
    performOperation :*
  end
  
  def divide
    performOperation :fdiv
  end
  
  def performOperation operator
    
    second_operand= self.pop
    first_operand=  self.pop
    @value= first_operand.send(operator, second_operand)
    @values.push @value
    @value
  end
  
  def pop
    value= @values.pop
    raise Exception, "calculator is empty" if value.nil?
    value
  end
  
  def tokens str
    tokenize str
  end
  
  def tokenize str
    
    tokens= str.split
    
    tokens.map do |token|
      case token
      
      when '+', '-', '*', '/'
        token.to_sym
      else
        token.to_i
      end
    end
    
    # tokens still equals str.split
  end
  
  def evaluate str
    
    tokens= tokenize str
    
    for token in tokens
      case token
      
      when :+
        self.plus
      when :-
        self.minus
      when :*
        self.times
      when :/
        self.divide
      else
        self.push token
      end
    end
    
    @value
  end
  
  # def plus
  #   second_operand= @values.pop
  #   first_operand=  @values.pop
    
  #   if first_operand.nil?
  #     raise Exception, "calculator is empty"
  #   end
    
  #   @value= first_operand + second_operand

  #   @values.push @value
    
  #   @value
  # end
  
  # def minus
  #   second_operand= @values.pop
  #   first_operand=  @values.pop
    
  #   if first_operand.nil?
  #     raise Exception, "calculator is empty"
  #   end

  #   @value= first_operand - second_operand

  #   @values.push @value
    
  #   @value
  # end
  
  # def times
  #   second_operand= @values.pop
  #   first_operand=  @values.pop
    
  #   if first_operand.nil?
  #     raise Exception, "calculator is empty"
  #   end
    
  #   @value= first_operand * second_operand

  #   @values.push @value
    
  #   @value
  # end
  
  # def divide
  #   second_operand= @values.pop
  #   first_operand=  @values.pop
    
  #   if first_operand.nil?
  #     raise Exception, "calculator is empty"
  #   end
    
  #   @value= first_operand.to_f / second_operand.to_f

  #   @values.push @value
    
  #   @value
  # end
end