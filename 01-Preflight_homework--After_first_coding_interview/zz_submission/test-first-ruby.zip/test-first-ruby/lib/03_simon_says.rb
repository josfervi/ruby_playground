
# Returns the string passed into it
# +str+:: the string
def echo(str)
  str
end

# Allcaps the string and returns it
# +str+:: the string
def shout(str)
  str.upcase
end

# Repetas the string n times, separating each pair of instances with a space
# +str+:: the string
# +n+:: +positive integer >=0+ the number of times
def repeat(str, n = 2)
  ([str] * n).join(" ")
end

# Returns the first n letters of word
# +word+:: +string+
# +n+::    +positive integer+
def start_of_word(word, n)
  if n > word.length
    n= word.length
  end
  
  word[0...n]
end

# Returns the first word of str or "" if there is str has no words
# +str+:: +string+
def first_word(str)
  words= str.split
  
  if words.empty?
    return ""
  end
  
  words.first
end

# Capitalizes non-little words of a title
# Capitalizes little words only at the start of a title
# +title+:: +string+
def titleize(title)
  titleize_impl0(title)
  # titleize_impl1(title)
  # titleize_impl2(title)
end

def titleize_impl0(title)
  words= title.split
  
  if words.empty?
    return ""
  end
  
  for word in words
    word.capitalize! unless word.isOneOf?(%w(and over the))
  end
  
  words.first.capitalize!
  
  words.join(" ")
end

def titleize_impl1(title)
  words= title.split
  
  if words.empty?
    return ""
  end
  
  # always capitalize the first word
  words.first.capitalize!
  
  dont_capitalize_these_words= Set.new ["and", "over", "the"]
  
  for word in words[1..-1]
    if dont_capitalize_these_words.include?(word)
      next
    end
    word.capitalize!
  end
  
  words.join(" ")
end

def titleize_impl2(title)
  words= title.split
  
  dont_capitalize_these_words= Set.new ["and", "over", "the"]
  
  for word, idx in words.map.with_index
    if idx == 0
      word.capitalize!
      next
    end
    if dont_capitalize_these_words.include?(word)
      next
    end
    word.capitalize!
  end
  
  words.join(" ")
end

class String
  def isOneOf?(strings)
    strings.include?(self)
  end
end