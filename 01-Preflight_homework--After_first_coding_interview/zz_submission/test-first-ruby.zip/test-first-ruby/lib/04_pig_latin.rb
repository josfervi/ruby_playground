# Translates str into pig latin
# +str+:: +string+
def translate(str)
  words= str.split
  
  res= []
  
  for word in words
    res.push( translateOneWord(word) )
  end
  
  res.join(" ")
end

# Translates word into pig latin
# +word+:: +string+
def translateOneWord(word)
  idx= _getPigLatinIdx(word)
  
  # initial guesses
  first_part=  word[ idx .. -1]
  second_part= word[ 0 ... idx]
  punctuation= ""
  
  # correct the guesses
  if _punctuated?(word)
    first_part=  word[idx .. -2]
    punctuation= word[-1]
  end

  if _capitalized?(word)
    first_part.capitalize!
    second_part.downcase!
  end
  
  first_part + second_part + "ay" + punctuation
end


def _getPigLatinIdx(word)
  idx= _getIdxOfFirstVowel(word)
  
  # handle "qu"
  if idx > 0
    prev_letter= word[idx-1].downcase
    letter=      word[idx].downcase
    
    if prev_letter + letter == "qu"
      idx+= 1
    end
  end
  
  idx
end

def _punctuated?(word)
  punctuations= Set.new [".", "?", "!", ",", ":", ";", "'", '"']
  
  punctuations.include?(word[-1])
end

def _capitalized?(word)
  word == word.capitalize
end

def _getIdxOfFirstVowel(word)
  idx= 0
  
  vowels= Set.new ["a", "e", "i", "o", "u"]
  
  while idx < word.length
    letter= word[idx].downcase
    
    if vowels.include?(letter)
      break
    end
    
    idx+= 1
  end
  
  idx
end